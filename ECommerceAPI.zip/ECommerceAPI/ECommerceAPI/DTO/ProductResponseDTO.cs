﻿namespace ECommerceAPI.DTO
{
    public class ProductResponseDTO
    {
        public int ProductId { get; set; }
    }
}