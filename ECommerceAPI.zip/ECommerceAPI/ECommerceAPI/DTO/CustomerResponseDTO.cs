﻿namespace ECommerceAPI.DTO
{
    public class CustomerResponseDTO
    {
        public int CustomerId { get; set; }
    }
}